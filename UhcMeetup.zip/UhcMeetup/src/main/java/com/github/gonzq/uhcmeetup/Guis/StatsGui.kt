package com.github.gonzq.uhcmeetup.Guis

import com.github.gonzq.uhcmeetup.Managers.StatsManager
import com.github.gonzq.uhcmeetup.UhcMeetup
import com.github.gonzq.uhcmeetup.Utils.Utils
import fr.mrmicky.fastinv.FastInv
import fr.mrmicky.fastinv.ItemBuilder
import org.bukkit.Material
import org.bukkit.entity.Player

class StatsGui(player: Player): FastInv(9, "游玩数据") {
    val pl = UhcMeetup.pl
    val stats = StatsManager.getInstance()

    init {
        val p = pl.pm.getUhcPlayer(player)
        addItem(ItemBuilder(Material.GOLD_BLOCK).name(Utils.chat("&a胜利数: ${stats.getValue(p, StatsManager.Stats.WINS)}")).build())
        addItem(ItemBuilder(Material.SKELETON_SKULL).name(Utils.chat("&c死亡数: ${stats.getValue(p, StatsManager.Stats.DEATHS)}")).build())
        addItem(ItemBuilder(Material.IRON_SWORD).name(Utils.chat("&c击杀数: ${stats.getValue(p, StatsManager.Stats.KILLS)}")).build())
        addItem(ItemBuilder(Material.GOLDEN_APPLE).name(Utils.chat("&6金苹果食用数: ${stats.getValue(p, StatsManager.Stats.GAPPS)}")).build())
        addItem(ItemBuilder(Material.ARROW).name(Utils.chat("&b射击数: ${stats.getValue(p, StatsManager.Stats.BOW_SHOOTS)}")).build())
        addItem(ItemBuilder(Material.GRASS_BLOCK).name(Utils.chat("&a游玩次数: ${stats.getValue(p, StatsManager.Stats.PLAYED)}")).build())

        addOpenHandler { e -> e.player.sendMessage(Utils.chat("${pl.prefix}打开了 ${p.name}的 游戏数据")) }
        addClickHandler {e -> e.isCancelled = true}
    }
}